# IP 检测台

Windows x64 版运行 `dist/IPCheckStation-Setup-x64.exe`。安装到当前用户，从开始菜单打开。需要 Microsoft Edge WebView2 Runtime。

Android 8.0 及以上安装 `dist/IPCheckStation-Android.apk`。应用需要支持现代 JavaScript 的 Android System WebView。APK 使用项目专用签名密钥。后续升级请使用同一密钥，密钥和密码文件保存在本地 `.build` 目录。

## 检测

打开软件即进入离线模式，输入 IPv4 或 IPv6 地址开始查询。每次成功检测各自保存，同一个 IP 的重复检测也保留。历史保存在本机，历史面板支持清空。

打开「在线检测」后，每次连接 api.ipquery.io 前都须确认。接收方可以看到公网出口 IP，指定地址查询时也会收到查询地址。地址栏留空可检测当前公网出口。免费在线结果可能缺少风险字段。当前免费数据未覆盖共享设备数量，因此显示「未知」。

「原生 IP 参考」比较定位国家与 RIR 分配登记国家，仅供参考。离线 IP 类型可能依据组织名称估算，未能识别时显示「未知」。

## 离线数据库来源

- [IP Geolocation and ASN by DB-IP](https://db-ip.com/db/lite.php)，DB-IP Lite 2026-11，按 [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) 授权。从原始 CSV 提取所需字段并转换为应用的本地二进制索引。
- [ipverse Country IP Blocks](https://github.com/ipverse/country-ip-blocks)，按 CC0 1.0 发布。以公开 RIR 分配记录生成查询索引，多方冲突时跳过对应区间。
- [IPQuery](https://ipquery.io/developers/api) 仅用于明确同意的在线查询。

## 构建

在项目根目录运行 `python app/pack-data.py`，读取 `.build` 中的 `country.csv.gz`、`asn.csv.gz` 和 `country-ip-source.tar.gz`。Windows 构建用 `windows/build.ps1`，需要将 WebView2 SDK NuGet 包解压到 `.build/webview2`。Android 构建用 `android/build.ps1`，需要设置 `JAVA_HOME`，并在 `.build/android-sdk` 或 `ANDROID_SDK_ROOT` 提供 Android SDK API 35 和 Build Tools 35.0.0。

运行 `node --test` 验证 IP 格式、离线数据和在线同意流程。
