package com.ipcheckstation.app;

import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Collections;

public final class MainActivity extends Activity {
    private static final String LOCAL = "appassets.androidplatform.net";
    private WebView view;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        view = new WebView(this);
        view.setBackgroundColor(Color.rgb(11, 17, 32));
        view.setImportantForAutofill(WebView.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSafeBrowsingEnabled(false);

        view.setWebChromeClient(new WebChromeClient());
        view.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest request) {
                return !isLocal(request.getUrl());
            }

            @Override public WebResourceResponse shouldInterceptRequest(WebView webView, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (isLocal(uri)) return localAsset(uri.getPath());
                if (!request.isForMainFrame() && "https".equals(uri.getScheme())
                        && "api.ipquery.io".equals(uri.getHost())) return null;
                return missing();
            }
        });
        setContentView(view);
        view.loadUrl("https://" + LOCAL + "/index.html");
    }

    private static boolean isLocal(Uri uri) {
        return "https".equals(uri.getScheme()) && LOCAL.equals(uri.getHost());
    }

    private WebResourceResponse localAsset(String path) {
        if (path == null) return missing();
        String mime;
        switch (path) {
            case "/index.html": mime = "text/html"; break;
            case "/style.css": mime = "text/css"; break;
            case "/data.js":
            case "/core.js":
            case "/ui.js": mime = "application/javascript"; break;
            default: return missing();
        }
        try {
            return new WebResourceResponse(mime, "UTF-8", getAssets().open(path.substring(1)));
        } catch (IOException error) {
            return missing();
        }
    }

    private static WebResourceResponse missing() {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
            Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
    }
}
