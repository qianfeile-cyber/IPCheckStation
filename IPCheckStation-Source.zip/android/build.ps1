param([string]$OutputDirectory = 'dist')
$ErrorActionPreference = 'Stop'
if (!$env:JAVA_HOME) { throw 'Set JAVA_HOME to JDK 17 or later.' }
$sdk = if ($env:ANDROID_SDK_ROOT) { $env:ANDROID_SDK_ROOT } else { '.build/android-sdk' }
$tools = Join-Path $sdk 'build-tools/35.0.0'
$platform = Join-Path $sdk 'platforms/android-35/android.jar'
$stage = '.build/android-package'
New-Item -ItemType Directory -Force $stage, "$stage/classes", "$stage/assets", "$stage/dex", $OutputDirectory | Out-Null
Copy-Item 'app/index.html', 'app/style.css', 'app/core.js', 'app/ui.js', 'app/data.js' "$stage/assets"
& "$env:JAVA_HOME/bin/javac.exe" -encoding UTF-8 --release 11 -classpath $platform -d "$stage/classes" android/MainActivity.java
if ($LASTEXITCODE) { throw 'Java compilation failed.' }
python android/zip-files.py "$stage/classes.jar" "$stage/classes" w
if ($LASTEXITCODE) { throw 'Java packaging failed.' }
& "$env:JAVA_HOME/bin/java.exe" -cp "$tools/lib/d8.jar" com.android.tools.r8.D8 --min-api 26 --lib $platform --output "$stage/dex" "$stage/classes.jar"
if ($LASTEXITCODE) { throw 'DEX compilation failed.' }
& "$tools/aapt2.exe" compile --dir android/res -o "$stage/resources.zip"
if ($LASTEXITCODE) { throw "Android resource compilation failed." }
& "$tools/aapt2.exe" link -I $platform "$stage/resources.zip" --manifest android/AndroidManifest.xml -A "$stage/assets" -o "$stage/unsigned.apk"
if ($LASTEXITCODE) { throw 'APK packaging failed.' }
python android/zip-files.py "$stage/unsigned.apk" "$stage/dex" a
if ($LASTEXITCODE) { throw 'Adding DEX failed.' }
& "$tools/zipalign.exe" -f 4 "$stage/unsigned.apk" "$stage/aligned.apk"
if ($LASTEXITCODE) { throw 'APK alignment failed.' }

$key = '.build/android-release.p12'
$passwordFile = '.build/android-signing-password.txt'
if (!(Test-Path $key)) {
    $password = [guid]::NewGuid().ToString('N')
    Set-Content -LiteralPath $passwordFile -Value $password -Encoding ascii
    & "$env:JAVA_HOME/bin/keytool.exe" -genkeypair -alias ipcheck -keyalg RSA -keysize 3072 -validity 10000 -keystore $key -storetype PKCS12 -storepass:file $passwordFile -dname 'CN=IP Check Station'
    if ($LASTEXITCODE) { throw 'APK signing key generation failed.' }
}
$apk = Join-Path $OutputDirectory 'IPCheckStation-Android.apk'
& "$env:JAVA_HOME/bin/java.exe" -jar "$tools/lib/apksigner.jar" sign --v4-signing-enabled false --ks $key --ks-pass "file:$passwordFile" --out $apk "$stage/aligned.apk"
if ($LASTEXITCODE) { throw 'APK signing failed.' }
& "$env:JAVA_HOME/bin/java.exe" -jar "$tools/lib/apksigner.jar" verify --verbose $apk
if ($LASTEXITCODE) { throw 'APK signature verification failed.' }


