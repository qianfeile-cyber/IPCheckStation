from pathlib import Path
from sys import argv
from zipfile import ZIP_DEFLATED, ZipFile

output, root, mode = argv[1:]
with ZipFile(output, mode, ZIP_DEFLATED) as archive:
    for item in Path(root).rglob("*"):
        if item.is_file():
            archive.write(item, item.relative_to(root).as_posix())
