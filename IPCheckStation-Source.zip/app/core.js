'use strict';

globalThis.IPCheck = (() => {
  function normalize(input) {
    const text = String(input).trim();
    if (/^\d{1,3}(\.\d{1,3}){3}$/.test(text)) {
      const octets = text.split('.');
      return octets.every(part => Number(part) < 256 && String(Number(part)) === part) ? text : '';
    }
    if (!text.includes(':') || !/^[\da-f:.]+$/i.test(text)) return '';
    try {
      return new URL('http://[' + text + ']/').hostname.slice(1, -1);
    } catch {
      return '';
    }
  }

  function addressNumber(ip) {
    if (!ip.includes(':')) {
      return ip.split('.').reduce((number, part) => (number << 8n) | BigInt(part), 0n);
    }
    const [left, right] = ip.split('::');
    const head = left ? left.split(':') : [];
    const tail = right ? right.split(':') : [];
    const zeros = right === undefined ? [] : Array(8 - head.length - tail.length).fill('0');
    return [...head, ...zeros, ...tail].reduce((number, part) => (number << 16n) | BigInt('0x' + part), 0n);
  }

  function catalog(rows) {
    const ranges = new Map();
    for (const row of rows) {
      const [address, prefix] = String(row.network).split('/');
      const ip = normalize(address);
      const bits = ip.includes(':') ? 128 : 32;
      const length = Number(prefix);
      if (!ip || !/^\d+$/.test(prefix) || length > bits) continue;
      const key = bits + '/' + length;
      if (!ranges.has(key)) ranges.set(key, new Map());
      ranges.get(key).set(addressNumber(ip) >> BigInt(bits - length), row);
    }
    return ranges;
  }

  function lookup(ranges, ip) {
    const bits = ip.includes(':') ? 128 : 32;
    const number = addressNumber(ip);
    for (let length = bits; length >= 0; length--) {
      const row = ranges.get(bits + '/' + length)?.get(number >> BigInt(bits - length));
      if (row) return row;
    }
    return {};
  }

  function lookupPacked(dataset, ip) {
    if (!dataset) return '';
    const wide = ip.includes(':');
    const field = wide ? 'v6' : 'v4';
    if (typeof dataset[field] === 'string') {
      dataset[field] = new DataView(Uint8Array.from(atob(dataset[field]), byte => byte.charCodeAt(0)).buffer);
    }
    const view = dataset[field];
    const width = wide ? 16 : 4;
    const stride = width * 2 + 4;
    const number = addressNumber(ip);
    const read = wide
      ? offset => (view.getBigUint64(offset) << 64n) | view.getBigUint64(offset + 8)
      : offset => BigInt(view.getUint32(offset));
    let low = 0;
    let high = view.byteLength / stride;
    while (low < high) {
      const middle = Math.floor((low + high) / 2);
      const offset = middle * stride;
      if (number < read(offset)) high = middle;
      else if (number > read(offset + width)) low = middle + 1;
      else return dataset.values[view.getUint32(offset + width * 2)];
    }
    return '';
  }

  function record(ip, local, response, mode) {
    const risk = response.risk ?? {};
    const location = response.location ?? {};
    const country = location.country_code || local.country || '';
    const registered = local.registered || '';
    const riskValue = risk.risk_score;
    const score = Number.isFinite(riskValue) && riskValue >= 0 && riskValue <= 100 ? riskValue : null;
    const networkType = risk.is_mobile === true ? '移动网络'
      : risk.is_datacenter === true ? '机房' : local.type || '未知';
    const native = country && registered ? (country === registered ? '一致' : '不一致') : '未知';
    const idBytes = crypto.getRandomValues(new Uint8Array(16));
    return {
      id: Array.from(idBytes, byte => byte.toString(16).padStart(2, '0')).join(''),
      time: new Date().toISOString(),
      ip, mode, country, registered, native,
      city: location.city || local.city || '',
      asn: response.isp?.asn || local.asn || '',
      org: response.isp?.org || response.isp?.isp || local.org || '',
      type: networkType, risk: score, devices: local.devices ?? null,
      devicePeriod: local.devicePeriod || '',
      flags: Object.fromEntries(['is_vpn', 'is_proxy', 'is_tor'].map(key => [key, typeof risk[key] === 'boolean' ? risk[key] : null]))
    };
  }

  return { normalize, catalog, lookup, lookupPacked, record };
})();
