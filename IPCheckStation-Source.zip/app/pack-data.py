import base64
from collections import Counter, defaultdict
import csv
import gzip
import ipaddress
import json
import tarfile
from pathlib import Path

build = Path(".build")


def address(value):
    return ipaddress.ip_address(value)


def dbip(name, transform):
    with gzip.open(build / (name + ".csv.gz"), "rt", encoding="utf-8", newline="") as stream:
        for row in csv.reader(stream):
            yield address(row[0]), address(row[1]), transform(row[2:])


def registrations():
    events = {4: defaultdict(Counter), 6: defaultdict(Counter)}
    with tarfile.open(build / "country-ip-source.tar.gz", "r:gz") as archive:
        for member in archive:
            parts = member.name.split("/")
            if len(parts) != 4 or parts[-1] not in {"ipv4-aggregated.txt", "ipv6-aggregated.txt"}:
                continue
            country = parts[-2].upper()
            if country in {"ZZ", "EU", "AP"}:
                continue
            with archive.extractfile(member) as stream:
                for line in stream:
                    text = line.decode("utf-8").strip()
                    if not text or text.startswith("#"):
                        continue
                    network = ipaddress.ip_network(text)
                    events[network.version][int(network.network_address)][country] += 1
                    events[network.version][int(network.broadcast_address) + 1][country] -= 1

    for version, points in events.items():
        address_class = ipaddress.IPv4Address if version == 4 else ipaddress.IPv6Address
        previous = 0
        active = Counter()
        for point, changes in sorted(points.items()):
            if len(active) == 1 and point > previous:
                yield address_class(previous), address_class(point - 1), next(iter(active))
            active.update(changes)
            active = +active
            previous = point


def pack(rows):
    values = {}
    payload = {}
    for version, width in ((4, 4), (6, 16)):
        data = bytearray()
        last = -1
        for start, end, value in sorted(rows[version], key=lambda row: (row[0], row[1])):
            if start <= last:
                raise ValueError(f"Overlapping ranges at {start}")
            last = end
            data.extend(start.to_bytes(width, "big"))
            data.extend(end.to_bytes(width, "big"))
            data.extend(values.setdefault(value, len(values)).to_bytes(4, "big"))
        payload["v" + str(version)] = base64.b64encode(data).decode("ascii")
    payload["values"] = list(values)
    return payload


datasets = {
    "country": dbip("country", lambda row: row[0] if row[0] != "ZZ" else ""),
    "asn": dbip("asn", lambda row: (row[0], row[1])),
    "registered": registrations(),
}
packed = {}
for name, rows in datasets.items():
    by_version = {4: [], 6: []}
    for start, end, value in rows:
        by_version[start.version].append((int(start), int(end), value))
    packed[name] = pack(by_version)
    print(name, *(len(rows) for rows in by_version.values()))

Path("app/data.js").write_text(
    "globalThis.IP_DATA = " + json.dumps(packed, ensure_ascii=True, separators=(",", ":")) + ";\n",
    encoding="utf-8",
)

