'use strict';

const {normalize, lookupPacked, record} = IPCheck;
const get = id => document.getElementById(id);
const historyKey = 'ipcheck.history.v2';
const api = 'https://api.ipquery.io/';
const unknown = '未知';
const riskLabels = ['风险很低', '风险较低', '风险中等', '风险较高', '风险很高'];
let entries = [];

function element(tag, value, className) {
  const node = document.createElement(tag);
  if (value !== undefined) node.textContent = value;
  if (className) node.className = className;
  return node;
}

function showStatus(message, error = false) {
  get('status').textContent = message;
  get('status').toggleAttribute('data-error', error);
}

function renderRisk(score) {
  const display = element('span', undefined, 'risk-display');
  const hasScore = Number.isFinite(score) && score >= 0 && score <= 100;
  const level = hasScore ? Math.min(riskLabels.length - 1, Math.floor(score / 20)) : -1;
  const pill = element('span', undefined, 'risk-pill risk-' + (hasScore ? level : 'unknown'));
  pill.append(element('strong', hasScore ? score + ' / 100' : unknown));
  if (hasScore) pill.append(element('span', riskLabels[level]));
  const scale = element('span', undefined, 'risk-scale');
  scale.setAttribute('aria-hidden', 'true');
  riskLabels.forEach((label, index) => {
    const color = hasScore ? index : 'unknown';
    scale.append(element('span', undefined, 'risk-dot risk-' + color + (index === level ? ' active' : '')));
  });
  display.append(pill, scale);
  return display;
}

function renderRecord(item) {
  const list = element('dl');
  const flag = value => value === true ? '是' : value === false ? '否' : unknown;
  const asn = item.asn ? 'AS' + String(item.asn).replace(/^AS/i, '') : unknown;
  const fields = [
    ['IP 类型', item.type],
    ['风控值', '', renderRisk(item.risk)],
    ['原生 IP 参考', item.native],
    ['共享设备数', item.devices === null ? unknown : item.devices + '（' + item.devicePeriod + '）'],
    ['定位国家 / 地区', [item.country, item.city].filter(Boolean).join(' · ')],
    ['登记国家 / 地区', item.registered],
    ['运营商 / 组织', item.org],
    ['ASN', asn],
    ['检测方式', item.mode === 'online' ? '在线 · IPQuery' : '离线'],
    ['VPN', flag(item.flags.is_vpn)],
    ['代理', flag(item.flags.is_proxy)],
    ['Tor', flag(item.flags.is_tor)]
  ];
  for (const [key, value, display] of fields) {
    const pair = element('div');
    const detail = element('dd', display ? undefined : value || unknown);
    if (display) detail.append(display);
    pair.append(element('dt', key), detail);
    list.append(pair);
  }
  return list;
}

function renderHistory() {
  get('count').textContent = entries.length ? String(entries.length) + ' 条' : '';
  get('empty').hidden = entries.length > 0;
  get('clear').disabled = entries.length === 0;
  const rows = entries.map(item => {
    const details = element('details', undefined, 'record');
    const summary = element('summary');
    const line = element('span', undefined, 'summary');
    const time = element('time', new Date(item.time).toLocaleString('zh-CN'));
    time.dateTime = item.time;
    line.append(element('strong', item.ip), time);
    summary.append(line);
    details.append(summary, renderRecord(item));
    return details;
  });
  get('history').replaceChildren(...rows);
}

function typeHint(org) {
  if (/\b(?:hosting|datacenter|data center|cloud|digitalocean|hetzner|amazon web services)\b/i.test(org)) return '机房（估算）';
  if (/\b(?:wireless|cellular|mobile)\b/i.test(org)) return '移动网络（估算）';
  if (/\b(?:residential|broadband|cable internet)\b/i.test(org)) return '住宅宽带（估算）';
  return unknown;
}

function offlineData(ip) {
  const data = globalThis.IP_DATA;
  const [asn = '', org = ''] = lookupPacked(data?.asn, ip) || [];
  return {
    country: lookupPacked(data?.country, ip),
    registered: lookupPacked(data?.registered, ip),
    asn, org, type: typeHint(org)
  };
}

function setOnlineText() {
  const online = get('online').checked;
  get('submit').textContent = online ? '在线检测' : '离线检测';
  get('mode').textContent = online
    ? '仅访问 IPQuery。留空时检测当前出口 IP。'
    : '离线模式。手动输入公网 IP 进行查询。';
}

get('online').checked = false;
get('online').addEventListener('change', setOnlineText);
setOnlineText();

get('form').addEventListener('submit', async event => {
  event.preventDefault();
  const online = get('online').checked;
  const input = get('ip').value.trim();
  let ip = normalize(input);
  if ((!online || input) && !ip) {
    showStatus('请输入有效的 IPv4 或 IPv6 地址。', true);
    return;
  }
  let response = {};
  if (online) {
    const sent = ip ? '\n\n查询地址：' + ip : '';
    if (!confirm('将访问 api.ipquery.io。该服务可以看到你当前的公网出口 IP。' + sent + '\n\n继续在线检测？')) return;
    get('submit').disabled = true;
    get('online').disabled = true;
    showStatus('正在查询 IPQuery…');
    const abort = new AbortController();
    const timer = setTimeout(() => abort.abort(), 12000);
    try {
      const url = ip ? api + ip : api + '?format=json';
      const result = await fetch(url, { credentials: 'omit', cache: 'no-store', redirect: 'error', signal: abort.signal });
      if (!result.ok) throw new Error('HTTP ' + result.status);
      response = await result.json();
      const returnedIp = normalize(response.ip || '');
      if (!returnedIp || (ip && ip !== returnedIp)) throw new Error('IP mismatch');
      ip = returnedIp;
    } catch {
      showStatus('在线检测失败。请检查网络，或关闭在线检测后查询。', true);
      return;
    } finally {
      clearTimeout(timer);
      get('submit').disabled = false;
      get('online').disabled = false;
    }
  }
  const item = record(ip, offlineData(ip), response, online ? 'online' : 'offline');
  get('result-body').replaceChildren(element('p', ip, 'ip'), renderRecord(item));
  get('result').hidden = false;
  try {
    const next = [item, ...entries];
    localStorage.setItem(historyKey, JSON.stringify(next));
    entries = next;
    renderHistory();
    showStatus('结果已保存到本机。');
  } catch {
    showStatus('检测完成。设备存储不足或不可用，本次结果未保存。', true);
  }
});

get('clear').addEventListener('click', () => {
  if (!confirm('清空此设备上的全部检测历史？')) return;
  try {
    localStorage.removeItem(historyKey);
    entries = [];
    renderHistory();
    showStatus('历史已清空。');
  } catch {
    showStatus('无法清空历史。', true);
  }
});

try {
  const stored = JSON.parse(localStorage.getItem(historyKey) || '[]');
  if (Array.isArray(stored)) entries = stored;
  renderHistory();
} catch {
  showStatus('无法读取本机历史。', true);
}

