import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import {webcrypto} from 'node:crypto';

const context = vm.createContext({ URL, atob, crypto: webcrypto });
vm.runInContext(readFileSync('app/core.js', 'utf8'), context);
const core = context.IPCheck;

test('validates and normalizes literal IPv4 and IPv6', () => {
  assert.equal(core.normalize(' 8.8.8.8 '), '8.8.8.8');
  assert.equal(core.normalize('2001:0DB8:0:0::1'), '2001:db8::1');
  assert.equal(core.normalize('127.1'), '');
  assert.equal(core.normalize('1.2.3.4:80'), '');
});

test('compares registered country with geolocation and preserves unknown values', () => {
  const unknown = core.record('8.8.8.8', {}, {}, 'offline');
  assert.equal(unknown.native, '未知');
  assert.equal(unknown.risk, null);
  assert.equal(unknown.devices, null);
  const matched = core.record('8.8.8.8', {country:'US', registered:'US'}, {risk:{risk_score:0}}, 'online');
  assert.equal(matched.native, '一致');
  assert.equal(matched.risk, 0);
  assert.notEqual(matched.id, unknown.id);
});

test('prefers a more specific local range and does not match outside it', () => {
  const catalog = core.catalog([{network:'8.0.0.0/8',country:'US'},{network:'8.8.8.0/24',country:'CA'}]);
  assert.equal(core.lookup(catalog, '8.8.8.8').country, 'CA');
  assert.equal(core.lookup(catalog, '8.9.8.8').country, 'US');
  assert.deepEqual(Object.keys(core.lookup(catalog, '9.9.9.9')), []);
});


test('bundled database resolves IPv4 and IPv6 offline', () => {
  vm.runInContext(readFileSync('app/data.js', 'utf8'), context);
  const data = context.IP_DATA;
  assert.equal(core.lookupPacked(data.asn, '8.8.8.8')[0], '15169');
  assert.equal(core.lookupPacked(data.registered, '8.8.8.8'), 'US');
  assert.equal(core.lookupPacked(data.asn, '2606:4700:4700::1111')[0], '13335');
  assert.equal(core.lookupPacked(data.registered, '192.168.1.1'), '');
});
