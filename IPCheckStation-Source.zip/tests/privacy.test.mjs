import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import {webcrypto} from 'node:crypto';

function loadPage({confirm = () => false, fetch, storage = new Map()} = {}) {
  class Element {
    children = [];
    events = new Map();
    checked = false;
    disabled = false;
    value = '';
    append(...children) { this.children.push(...children); }
    replaceChildren(...children) { this.children = children; }
    toggleAttribute() {}
    addEventListener(name, handler) { this.events.set(name, handler); }
  }
  const fields = new Map();
  const get = id => {
    if (!fields.has(id)) fields.set(id, new Element());
    return fields.get(id);
  };
  const context = vm.createContext({
    URL, atob, crypto: webcrypto, AbortController, setTimeout, clearTimeout,
    document: {getElementById: get, createElement: () => new Element()},
    localStorage: {
      getItem: key => storage.get(key),
      setItem: (key, value) => storage.set(key, value),
      removeItem: key => storage.delete(key)
    },
    confirm, fetch,
  });
  for (const name of ['core', 'ui']) {
    vm.runInContext(readFileSync('app/' + name + '.js', 'utf8'), context);
  }
  return {get, submit: () => get('form').events.get('submit')({preventDefault() {}})};
}

test('startup and offline detection do not fetch, and repeated addresses survive reload', async () => {
  let calls = 0;
  const storage = new Map();
  const settings = {storage, fetch() { calls++; }};
  const page = loadPage(settings);
  assert.equal(page.get('online').checked, false);
  page.get('ip').value = '8.8.8.8';
  await page.submit();
  await page.submit();
  assert.equal(calls, 0);
  assert.equal(loadPage(settings).get('history').children.length, 2);
});

test('declining online consent prevents a request', async () => {
  let calls = 0;
  const page = loadPage({fetch() { calls++; }});
  page.get('online').checked = true;
  await page.submit();
  assert.equal(calls, 0);
});

test('online consent permits only the specified lookup and saves returned risk', async () => {
  const storage = new Map();
  const urls = [];
  const page = loadPage({storage, confirm: () => true, async fetch(url) {
    urls.push(url);
    return {ok: true, async json() { return {ip:'8.8.8.8', risk:{risk_score:0}}; }};
  }});
  page.get('online').checked = true;
  page.get('ip').value = '8.8.8.8';
  await page.submit();
  assert.deepEqual(urls, ['https://api.ipquery.io/8.8.8.8']);
  const [record] = JSON.parse(storage.get('ipcheck.history.v2'));
  assert.equal(record.risk, 0);
  assert.equal(record.mode, 'online');
  assert.equal(record.devices, null);
});
