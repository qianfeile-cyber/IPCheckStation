import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import {webcrypto} from 'node:crypto';

function loadPage({confirm = () => false, fetch, storage = new Map()} = {}) {
  class Element {
    children = [];
    events = new Map();
    checked = false;
    disabled = false;
    value = '';
    append(...children) { this.children.push(...children); }
    replaceChildren(...children) { this.children = children; }
    setAttribute() {}
    toggleAttribute() {}
    addEventListener(name, handler) { this.events.set(name, handler); }
  }
  const fields = new Map();
  const get = id => {
    if (!fields.has(id)) fields.set(id, new Element());
    return fields.get(id);
  };
  const context = vm.createContext({
    URL, atob, crypto: webcrypto, AbortController, setTimeout, clearTimeout,
    document: {getElementById: get, createElement: () => new Element()},
    localStorage: {
      getItem: key => storage.get(key),
      setItem: (key, value) => storage.set(key, value),
      removeItem: key => storage.delete(key)
    },
    confirm, fetch,
  });
  for (const name of ['core', 'ui']) {
    vm.runInContext(readFileSync('app/' + name + '.js', 'utf8'), context);
  }
  return {get, submit: () => get('form').events.get('submit')({preventDefault() {}})};
}

test('startup and offline detection do not fetch, and repeated addresses survive reload', async () => {
  let calls = 0;
  const storage = new Map();
  const settings = {storage, fetch() { calls++; }};
  const page = loadPage(settings);
  assert.equal(page.get('online').checked, false);
  page.get('ip').value = '8.8.8.8';
  await page.submit();
  await page.submit();
  assert.equal(calls, 0);
  assert.equal(loadPage(settings).get('history').children.length, 2);
});

test('declining online consent prevents a request', async () => {
  let calls = 0;
  const page = loadPage({fetch() { calls++; }});
  page.get('online').checked = true;
  await page.submit();
  assert.equal(calls, 0);
});

test('online consent permits only the specified lookup and saves returned risk', async () => {
  const storage = new Map();
  const urls = [];
  const page = loadPage({storage, confirm: () => true, async fetch(url) {
    urls.push(url);
    return {ok: true, async json() { return {ip:'8.8.8.8', risk:{risk_score:0}}; }};
  }});
  page.get('online').checked = true;
  page.get('ip').value = '8.8.8.8';
  await page.submit();
  assert.deepEqual(urls, ['https://api.ipquery.io/8.8.8.8']);
  const [record] = JSON.parse(storage.get('ipcheck.history.v2'));
  assert.equal(record.risk, 0);
  assert.equal(record.mode, 'online');
  assert.equal(record.devices, null);
});

test('risk grade is displayed for a valid zero and suppressed when unavailable', async () => {
  const page = loadPage({confirm: () => true, async fetch() {
    return {ok: true, async json() { return {ip:'8.8.8.8', risk:{risk_score:0}}; }};
  }});
  const text = node => [node.textContent, ...node.children.flatMap(text)].filter(Boolean);
  page.get('ip').value = '8.8.8.8';
  await page.submit();
  assert.ok(!text(page.get('result-body')).includes('风险很低'));
  page.get('online').checked = true;
  await page.submit();
  for (const panel of ['result-body', 'history']) {
    const values = text(page.get(panel));
    assert.ok(values.includes('0 / 100'));
    assert.ok(values.includes('风险很低'));
  }
});

test('risk thresholds cover the full scale without classifying missing scores', async () => {
  const storage = new Map();
  const scores = [null, 19, 20, 40, 60, 80, 100];
  storage.set('ipcheck.history.v2', JSON.stringify(scores.map((risk) => ({
    ip: '8.8.8.8', time: '2026-11-21T00:00:00Z', risk, flags: {}, devices: null
  }))));
  const page = loadPage({storage});
  const tiles = page.get('history').children.map(row => row.children[1].children[1].children[1]);
  assert.deepEqual(tiles.map(tile => tile.children[0].children[0].className), [
    'risk-pill risk-unknown', 'risk-pill risk-0', 'risk-pill risk-1',
    'risk-pill risk-2', 'risk-pill risk-3', 'risk-pill risk-4', 'risk-pill risk-4'
  ]);
});
