﻿param([string]$Installer = 'dist/IPCheckStation-Setup-x64.exe')
$ErrorActionPreference = 'Stop'
$assembly = [Reflection.Assembly]::LoadFile((Resolve-Path -LiteralPath $Installer).Path)
$setup = $assembly.GetType('Setup')
$flags = [Reflection.BindingFlags]'NonPublic,Static'
$create = $setup.GetMethod('TryCreateDesktopShortcut', $flags)
$remove = $setup.GetMethod('RemoveDesktopShortcut', $flags)
if ($null -eq $create -or $null -eq $remove) { throw 'Desktop shortcut support is missing.' }

$testRoot = (New-Item -ItemType Directory -Force ('.build/shortcut-test-' + [Guid]::NewGuid().ToString('N'))).FullName
$link = [IO.Path]::Combine($testRoot, 'IP 检测台（IPCheckStation）.lnk')
$oldFolder = [IO.Path]::Combine($testRoot, '旧 安装')
$newFolder = [IO.Path]::Combine($testRoot, '新 安装')
$otherTarget = [IO.Path]::Combine($testRoot, 'Other.exe')
$shell = New-Object -ComObject WScript.Shell

try {
    if (!$create.Invoke($null, @($link, $oldFolder, $null))) { throw 'Shortcut was not created.' }
    if ($shell.CreateShortcut($link).TargetPath -ne [IO.Path]::Combine($oldFolder, 'IPCheckStation.exe')) {
        throw 'Shortcut does not target the chosen installation directory.'
    }
    if (!$create.Invoke($null, @($link, $newFolder, $oldFolder))) { throw 'Upgrade did not replace the old shortcut.' }
    if ($shell.CreateShortcut($link).TargetPath -ne [IO.Path]::Combine($newFolder, 'IPCheckStation.exe')) {
        throw 'Upgrade did not update the shortcut target.'
    }
    $null = $remove.Invoke($null, @($link, $newFolder))
    if ([IO.File]::Exists($link)) { throw 'Uninstall did not remove its shortcut.' }

    $unrelated = $shell.CreateShortcut($link)
    $unrelated.TargetPath = $otherTarget
    $unrelated.Save()
    if ($create.Invoke($null, @($link, $newFolder, $null))) { throw 'Unrelated shortcut was overwritten.' }
    $null = $remove.Invoke($null, @($link, $newFolder))
    if ($shell.CreateShortcut($link).TargetPath -ne $otherTarget) { throw 'Unrelated shortcut was removed.' }
    'Desktop shortcut creation, upgrade, uninstall and collision protection passed.'
} finally {
    [IO.File]::Delete($link)
    [IO.Directory]::Delete($testRoot)
}
