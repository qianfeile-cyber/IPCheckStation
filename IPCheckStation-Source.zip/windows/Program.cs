﻿using System;
using System.IO;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new MainWindow());
    }
}

internal sealed class MainWindow : Form
{
    private const string AppHost = "ipcheck.local";
    private readonly WebView2 view = new WebView2();

    internal MainWindow()
    {
        Text = "IP 检测台";
        Size = new System.Drawing.Size(960, 880);
        MinimumSize = new System.Drawing.Size(390, 500);
        StartPosition = FormStartPosition.CenterScreen;
        view.Dock = DockStyle.Fill;
        Controls.Add(view);
        Shown += Initialize;
    }

    private async void Initialize(object sender, EventArgs args)
    {
        try
        {
            string data = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "IPCheckStation", "WebView");
            var options = new CoreWebView2EnvironmentOptions(
                "--disable-background-networking --disable-component-update");
            var environment = await CoreWebView2Environment.CreateAsync(null, data, options);
            await view.EnsureCoreWebView2Async(environment);
            var browser = view.CoreWebView2;
            browser.Settings.AreDefaultContextMenusEnabled = false;
            browser.Settings.AreDevToolsEnabled = false;
            browser.Settings.IsGeneralAutofillEnabled = false;
            browser.Settings.IsPasswordAutosaveEnabled = false;
            browser.NavigationStarting += (s, e) => {
                Uri uri;
                e.Cancel = !Uri.TryCreate(e.Uri, UriKind.Absolute, out uri)
                    || uri.Scheme != Uri.UriSchemeHttps || uri.Host != AppHost;
            };
            browser.NewWindowRequested += (s, e) => e.Handled = true;
            browser.SetVirtualHostNameToFolderMapping(AppHost,
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "app"),
                CoreWebView2HostResourceAccessKind.Deny);
            browser.Navigate("https://" + AppHost + "/index.html");
        }
        catch (Exception error)
        {
            MessageBox.Show(this, "无法启动 IP 检测台。请检查 Microsoft Edge WebView2 Runtime 是否已安装。\n\n"
                + error.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            Close();
        }
    }
}

