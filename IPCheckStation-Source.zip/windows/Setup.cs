﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

internal static class Setup
{
    private const string Product = "IP 检测台";
    private const string AppName = "IPCheckStation.exe";
    private const string UninstallName = "Uninstall.exe";
    private const string ProductKey = @"Software\Microsoft\Windows\CurrentVersion\Uninstall\IPCheckStation";
    private static readonly string DefaultFolder = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "IPCheckStation");
    private static readonly string Shortcut = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.Programs), Product + ".lnk");
    private const string DesktopShortcutName = "IP 检测台（IPCheckStation）.lnk";

    [STAThread]
    private static void Main(string[] args)
    {
        Application.EnableVisualStyles();
        try
        {
            if (args.Length == 3 && args[0] == "/cleanup")
            {
                Cleanup(args[1], int.Parse(args[2]));
                return;
            }
            if (Array.IndexOf(args, "/uninstall") >= 0)
            {
                string folder = Path.GetDirectoryName(Application.ExecutablePath);
                if (MessageBox.Show("卸载 IP 检测台？此设备的检测历史会保留。", Product,
                    MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK) StartCleanup(folder);
                return;
            }

            string destination = ChooseFolder();
            if (destination == null) return;
            string previous = RegisteredFolder();
            Install(destination);
            if (MessageBox.Show("要在桌面创建「IP 检测台（IPCheckStation）」快捷方式吗？", Product,
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                OfferDesktopShortcut(destination, previous);
            if (MessageBox.Show("安装完成。现在打开 IP 检测台？", Product,
                MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                Process.Start(Path.Combine(destination, AppName));
        }
        catch (Exception error)
        {
            MessageBox.Show(error.Message, Product, MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private static string RegisteredFolder()
    {
        using (var key = Registry.CurrentUser.OpenSubKey(ProductKey))
            return key == null ? null : key.GetValue("InstallLocation") as string;
    }

    private static string ChooseFolder()
    {
        string previous = RegisteredFolder();
        using (var dialog = new FolderBrowserDialog())
        {
            dialog.Description = "选择 IP 检测台的安装文件夹。请使用空文件夹，或选择原安装文件夹。";
            dialog.ShowNewFolderButton = true;
            dialog.SelectedPath = Directory.Exists(previous) ? previous
                : Directory.Exists(DefaultFolder) ? DefaultFolder : Path.GetDirectoryName(DefaultFolder);

            var choice = MessageBox.Show("默认安装位置：\n" + (previous ?? DefaultFolder)
                + "\n\n选择「是」使用该位置，选择「否」浏览并自选文件夹。", Product,
                MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (choice == DialogResult.Cancel) return null;
            if (choice == DialogResult.Yes) return ValidateFolder(previous ?? DefaultFolder, previous);
            while (dialog.ShowDialog() == DialogResult.OK)
            {
                try { return ValidateFolder(dialog.SelectedPath, previous); }
                catch (IOException error)
                {
                    MessageBox.Show(error.Message, Product, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            return null;
        }
    }

    private static string ValidateFolder(string path, string previous)
    {
        string folder = Path.GetFullPath(path);
        if (String.Equals(folder, Path.GetPathRoot(folder), StringComparison.OrdinalIgnoreCase))
            throw new IOException("请选择磁盘下的文件夹。");
        folder = folder.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        if (Directory.Exists(folder) && !SamePath(folder, previous))
        {
            using (var children = Directory.EnumerateFileSystemEntries(folder).GetEnumerator())
                if (children.MoveNext() && !IsStationFolder(folder))
                    throw new IOException("所选文件夹包含其他文件。请选择空文件夹，或新建一个文件夹。");
        }
        return folder;
    }

    private static bool SamePath(string left, string right)
    {
        return String.Equals(left, right, StringComparison.OrdinalIgnoreCase);
    }

    private static bool IsStationFolder(string folder)
    {
        return File.Exists(Path.Combine(folder, AppName))
            && File.Exists(Path.Combine(folder, UninstallName))
            && File.Exists(Path.Combine(folder, "app", "index.html"));
    }

    private static void Install(string folder)
    {
        string appPath = Path.Combine(folder, AppName);
        string uninstaller = Path.Combine(folder, UninstallName);
        Directory.CreateDirectory(folder);
        using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("station.zip"))
        using (var archive = new ZipArchive(stream, ZipArchiveMode.Read))
        {
            foreach (var entry in archive.Entries)
            {
                string path = PayloadPath(folder, entry.FullName);
                Directory.CreateDirectory(Path.GetDirectoryName(path));
                entry.ExtractToFile(path, true);
            }
        }
        if (!SamePath(Application.ExecutablePath, uninstaller))
            File.Copy(Application.ExecutablePath, uninstaller, true);

        SaveShortcut(OpenShortcut(Shortcut), folder);

        using (var key = Registry.CurrentUser.CreateSubKey(ProductKey))
        {
            key.SetValue("DisplayName", Product);
            key.SetValue("DisplayVersion", "1.2.0");
            key.SetValue("InstallLocation", folder);
            key.SetValue("DisplayIcon", appPath);
            key.SetValue("UninstallString", "\"" + uninstaller + "\" /uninstall");
            key.SetValue("NoModify", 1, RegistryValueKind.DWord);
            key.SetValue("NoRepair", 1, RegistryValueKind.DWord);
        }
    }

    private static string DesktopShortcutPath()
    {
        string desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
        if (String.IsNullOrEmpty(desktop)) throw new IOException("找不到当前用户的桌面文件夹。");
        return Path.Combine(desktop, DesktopShortcutName);
    }

    private static dynamic OpenShortcut(string path)
    {
        dynamic shell = Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell"));
        return shell.CreateShortcut(path);
    }

    private static void SaveShortcut(dynamic shortcut, string folder)
    {
        shortcut.TargetPath = Path.Combine(folder, AppName);
        shortcut.WorkingDirectory = folder;
        shortcut.Save();
    }

    private static void OfferDesktopShortcut(string folder, string previous)
    {
        try
        {
            if (TryCreateDesktopShortcut(DesktopShortcutPath(), folder, previous)) return;
            MessageBox.Show("桌面上已有同名快捷方式。安装已完成，可从开始菜单打开。", Product,
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception error)
        {
            MessageBox.Show("安装已完成，但桌面快捷方式未创建。\n\n" + error.Message, Product,
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private static bool TryCreateDesktopShortcut(string path, string folder, string previous)
    {
        dynamic shortcut = OpenShortcut(path);
        if (File.Exists(path))
        {
            string target = shortcut.TargetPath;
            if (!SamePath(target, Path.Combine(folder, AppName))
                && (previous == null || !SamePath(target, Path.Combine(previous, AppName)))) return false;
        }
        SaveShortcut(shortcut, folder);
        return true;
    }

    private static void RemoveDesktopShortcut(string path, string folder)
    {
        if (!File.Exists(path)) return;
        string target = OpenShortcut(path).TargetPath;
        if (SamePath(target, Path.Combine(folder, AppName))) File.Delete(path);
    }

    private static string PayloadPath(string folder, string relative)
    {
        string path = Path.GetFullPath(Path.Combine(folder, relative));
        if (!path.StartsWith(folder + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("安装文件路径无效。");
        return path;
    }

    private static void StartCleanup(string folder)
    {
        if (!IsStationFolder(folder)) throw new IOException("找不到完整的 IP 检测台安装。");
        string helper = Path.Combine(Path.GetTempPath(), "IPCheckStation-Uninstall-" + Guid.NewGuid().ToString("N") + ".exe");
        File.Copy(Application.ExecutablePath, helper);
        Process.Start(new ProcessStartInfo(helper,
            "/cleanup \"" + folder + "\" " + Process.GetCurrentProcess().Id) { UseShellExecute = false });
    }

    private static void Cleanup(string folder, int parentId)
    {
        try
        {
            using (var parent = Process.GetProcessById(parentId))
                if (!parent.WaitForExit(15000)) throw new IOException("无法完成卸载，请关闭安装程序后重试。");
        }
        catch (ArgumentException) { }
        if (Path.GetPathRoot(folder) == folder || !IsStationFolder(folder)) return;
        using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("station.zip"))
        using (var archive = new ZipArchive(stream, ZipArchiveMode.Read))
            foreach (var entry in archive.Entries)
                File.Delete(PayloadPath(folder, entry.FullName));
        File.Delete(Path.Combine(folder, UninstallName));
        DeleteIfEmpty(Path.Combine(folder, "app"));
        DeleteIfEmpty(folder);
        if (SamePath(folder, RegisteredFolder()))
        {
            File.Delete(Shortcut);
            Registry.CurrentUser.DeleteSubKeyTree(ProductKey, false);
        }
        string desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
        if (!String.IsNullOrEmpty(desktop))
            RemoveDesktopShortcut(Path.Combine(desktop, DesktopShortcutName), folder);
    }

    private static void DeleteIfEmpty(string path)
    {
        if (!Directory.Exists(path)) return;
        using (var children = Directory.EnumerateFileSystemEntries(path).GetEnumerator())
            if (!children.MoveNext()) Directory.Delete(path);
    }
}
