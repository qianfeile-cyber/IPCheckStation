﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Windows.Forms;
using Microsoft.Win32;

internal static class Setup
{
    private const string Product = "IP 检测台";
    private const string ProductKey = @"Software\Microsoft\Windows\CurrentVersion\Uninstall\IPCheckStation";
    private static readonly string Folder = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "IPCheckStation");
    private static readonly string Shortcut = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.Programs), Product + ".lnk");
    private static readonly string AppPath = Path.Combine(Folder, "IPCheckStation.exe");
    private static readonly string Uninstaller = Path.Combine(Folder, "Uninstall.exe");

    [STAThread]
    private static void Main(string[] args)
    {
        Application.EnableVisualStyles();
        try
        {
            if (Array.IndexOf(args, "/uninstall") >= 0)
            {
                if (MessageBox.Show("卸载 IP 检测台？此设备的检测历史会保留。", Product,
                    MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK) Uninstall();
                return;
            }

            if (MessageBox.Show("将 IP 检测台安装到当前 Windows 用户。\n\n" + Folder,
                Product, MessageBoxButtons.OKCancel, MessageBoxIcon.Question) != DialogResult.OK) return;
            Install();
            if (MessageBox.Show("安装完成。现在打开 IP 检测台？", Product,
                MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                Process.Start(AppPath);
        }
        catch (Exception error)
        {
            MessageBox.Show(error.Message, Product, MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private static void Install()
    {
        Directory.CreateDirectory(Folder);
        using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("station.zip"))
        using (var archive = new ZipArchive(stream, ZipArchiveMode.Read))
        {
            foreach (var entry in archive.Entries)
            {
                string path = Path.GetFullPath(Path.Combine(Folder, entry.FullName));
                if (!path.StartsWith(Folder + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException("安装文件路径无效。");
                Directory.CreateDirectory(Path.GetDirectoryName(path));
                entry.ExtractToFile(path, true);
            }
        }
        File.Copy(Application.ExecutablePath, Uninstaller, true);

        Type shellType = Type.GetTypeFromProgID("WScript.Shell");
        dynamic shell = Activator.CreateInstance(shellType);
        dynamic shortcut = shell.CreateShortcut(Shortcut);
        shortcut.TargetPath = AppPath;
        shortcut.WorkingDirectory = Folder;
        shortcut.Save();

        using (var key = Registry.CurrentUser.CreateSubKey(ProductKey))
        {
            key.SetValue("DisplayName", Product);
            key.SetValue("DisplayVersion", "1.0.0");
            key.SetValue("InstallLocation", Folder);
            key.SetValue("DisplayIcon", AppPath);
            key.SetValue("UninstallString", "\"" + Uninstaller + "\" /uninstall");
            key.SetValue("NoModify", 1, RegistryValueKind.DWord);
            key.SetValue("NoRepair", 1, RegistryValueKind.DWord);
        }
    }

    private static void Uninstall()
    {
        File.Delete(Shortcut);
        Registry.CurrentUser.DeleteSubKeyTree(ProductKey, false);
        // The executable is locked until this process exits.
        var info = new ProcessStartInfo(Environment.ExpandEnvironmentVariables(@"%SystemRoot%\System32\cmd.exe"),
            "/d /s /c \"timeout /t 2 /nobreak >nul & rmdir /s /q \"" + Folder + "\"\"");
        info.UseShellExecute = false;
        info.CreateNoWindow = true;
        Process.Start(info);
    }
}
