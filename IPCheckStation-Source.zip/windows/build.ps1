param([ValidateSet("x64", "x86")][string]$Architecture = "x64")
$ErrorActionPreference = 'Stop'
$csc = Join-Path $env:windir 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$package = '.build/webview2'
$stage = ".build/win-package-$Architecture"
New-Item -ItemType Directory -Force $stage, "$stage/app", 'dist' | Out-Null
$webViewLib = "$package/lib/net462"
Copy-Item "$webViewLib/Microsoft.Web.WebView2.Core.dll", "$webViewLib/Microsoft.Web.WebView2.WinForms.dll" $stage
Copy-Item "$package/runtimes/win-$Architecture/native/WebView2Loader.dll" $stage
Copy-Item 'app/index.html', 'app/style.css', 'app/core.js', 'app/ui.js', 'app/data.js' "$stage/app"
& $csc /nologo /target:winexe "/platform:$Architecture" "/out:$stage/IPCheckStation.exe" "/r:$webViewLib/Microsoft.Web.WebView2.Core.dll" "/r:$webViewLib/Microsoft.Web.WebView2.WinForms.dll" (Resolve-Path windows/Program.cs).Path
if ($LASTEXITCODE) { throw 'Windows application compilation failed.' }
Compress-Archive -Path "$stage/*" -DestinationPath ".build/station-$Architecture.zip" -Force
& $csc /nologo /target:winexe "/platform:$Architecture" "/out:dist/IPCheckStation-Setup-$Architecture.exe" "/resource:.build/station-$Architecture.zip,station.zip" /r:System.IO.Compression.dll /r:System.IO.Compression.FileSystem.dll /r:Microsoft.CSharp.dll (Resolve-Path windows/Setup.cs).Path
if ($LASTEXITCODE) { throw 'Windows installer compilation failed.' }


